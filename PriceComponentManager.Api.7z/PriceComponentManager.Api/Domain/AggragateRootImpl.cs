﻿namespace PriceComponentManager.Api.Domain
{
	public class AggragateRootImpl : AggregateRoot
	{
		public AggragateRootImpl()
			: base()
		{
		}
	}
}