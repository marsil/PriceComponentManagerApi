﻿namespace PriceComponentManager.Api.Models
{
	public enum ModelType
	{
		CarRental
	}
}