﻿namespace PriceComponentManager.Api.Storage.Memento
{
	public class Memento
	{
	}
}