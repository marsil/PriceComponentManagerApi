﻿namespace PriceComponentManager.Api.Commands
{
	public class CommandType
	{
		public const string Created = "Created";

		public const string Updated = "Updated";

		public const string Deleted = "CarRentalDelted";
	}
}